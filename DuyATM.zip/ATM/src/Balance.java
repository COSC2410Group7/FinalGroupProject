import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Balance extends ATM {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel contentPaneBalance;
	private JTextField textField;
	public Balance() {
		setTitle("Balance");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 800, 450);
		contentPaneBalance = new JPanel();
		contentPaneBalance.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPaneBalance);
		contentPaneBalance.setLayout(null);
		
		JLabel lblBalance = new JLabel("Balance");
		lblBalance.setHorizontalAlignment(SwingConstants.CENTER);
		lblBalance.setFont(new Font("Tahoma", Font.PLAIN, 40));
		lblBalance.setBounds(193, 28, 380, 49);
		contentPaneBalance.add(lblBalance);
		
		JLabel lblSign = new JLabel("$");
		lblSign.setHorizontalAlignment(SwingConstants.CENTER);
		lblSign.setFont(new Font("Tahoma", Font.PLAIN, 50));
		lblSign.setBounds(216, 88, 43, 59);
		contentPaneBalance.add(lblSign);
		
		JButton btnReturn = new JButton("Return");
		btnReturn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				login.panel.removeAll();
				login.panel.add(menu.contentPaneMenu);
				login.panel.revalidate();
				login.panel.repaint();
			}
		});
		btnReturn.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnReturn.setBackground(new Color(255, 0, 51));
		btnReturn.setBounds(612, 333, 162, 67);
		contentPaneBalance.add(btnReturn);
		
		JLabel lblAmount = new JLabel(accountInfo[3]);
		lblAmount.setHorizontalAlignment(SwingConstants.CENTER);
		lblAmount.setFont(new Font("Tahoma", Font.PLAIN, 50));
		lblAmount.setBounds(269, 88, 255, 59);
		contentPaneBalance.add(lblAmount);
		
		JButton btnShowBalance = new JButton("Show Balance");
		btnShowBalance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText(accountInfo[3]);
			}
		});
		btnShowBalance.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnShowBalance.setBackground(new Color(255, 204, 51));
		btnShowBalance.setBounds(10, 333, 247, 67);
		contentPaneBalance.add(btnShowBalance);
		
		JLabel lblOriginalBalance = new JLabel("Original:");
		lblOriginalBalance.setFont(new Font("Tahoma", Font.PLAIN, 40));
		lblOriginalBalance.setHorizontalAlignment(SwingConstants.RIGHT);
		lblOriginalBalance.setBounds(10, 97, 196, 49);
		contentPaneBalance.add(lblOriginalBalance);
		
		JLabel lblNew = new JLabel("New:");
		lblNew.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNew.setFont(new Font("Tahoma", Font.PLAIN, 40));
		lblNew.setBounds(10, 197, 196, 49);
		contentPaneBalance.add(lblNew);
		
		JLabel label = new JLabel("$");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("Tahoma", Font.PLAIN, 50));
		label.setBounds(216, 188, 43, 59);
		contentPaneBalance.add(label);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setEditable(false);
		textField.setFont(new Font("Tahoma", Font.PLAIN, 50));
		textField.setBounds(269, 197, 255, 49);
		contentPaneBalance.add(textField);
		textField.setColumns(10);
	}
}
