import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.awt.CardLayout;
public class Login extends ATM {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField accountField;
	private JPasswordField passwordField;
	private JLabel lblError;
	private int attemptCount=0;
	public JPanel panel;
	JPanel contentPaneLogin;
	private JLabel lblYourAccountIs;
	public Login() {
		setTitle("ATM");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 250, 800, 450);
		panel = new JPanel();
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(panel);
		panel.setLayout(new CardLayout(0, 0));
		
		contentPaneLogin = new JPanel();
		panel.add(contentPaneLogin, "name_2096823609730483");
		contentPaneLogin.setLayout(null);
		
		accountField = new JTextField();
		accountField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {
				if (arg0.getKeyCode() == KeyEvent.VK_ENTER){
					if(accountInfo[4].equals("Active")){
						if (accountField.getText().equals(ATM.accountPW[0]) && Arrays.equals(passwordField.getPassword(), Password)){
							login.panel.remove(contentPaneLogin);
							login.panel.add(menu.contentPaneMenu);
							login.panel.revalidate();
							login.panel.repaint();
							attemptCount=0;
						}
						else{
							attemptCount++;
							if (attemptCount == 3){
								lblYourAccountIs.setVisible(true);
								ActionListener erase = new ActionListener() {
									public void actionPerformed(ActionEvent e){
										lblYourAccountIs.setVisible(false);
									}
								};
								Timer error = new Timer(10000,erase);
								error.start();
								error.setRepeats(false);
								
								String status = new String();
								status = "Inactive";
								accountInfo[4]=status;
								PrintWriter writer;
								try {
									writer = new PrintWriter(new FileOutputStream("AccountInformation.txt"));
									BufferedWriter bwriter = new BufferedWriter(writer);
									for(int i=0;i<5;i++){
										bwriter.write(accountInfo[i]);
										if(i!=4)
											bwriter.newLine();
									}
									bwriter.close();
								}
								catch (IOException e1) {
									// 	TODO Auto-generated catch block
									e1.printStackTrace();
								}
								ActionListener recovery = new ActionListener() {
									public void actionPerformed(ActionEvent e){
										String status = "Active";
										accountInfo[4]=status;
										PrintWriter writer;
										try{
											writer = new PrintWriter(new FileOutputStream("AccountInformation.txt"));
											BufferedWriter bwriter = new BufferedWriter(writer);
											for(int i=0;i<5;i++){
												bwriter.write(accountInfo[i]);
												if(i!=4)
													bwriter.newLine();
											}
											bwriter.close();
											attemptCount=0;
										}
										catch (IOException e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
									}
								};
								Timer changeStatus = new Timer(10000,recovery);
								changeStatus.start();
								changeStatus.setRepeats(false);
							}
							lblError.setVisible(true);
							ActionListener erase = new ActionListener() {
								public void actionPerformed(ActionEvent e){
									lblError.setVisible(false);
								}
							};
							Timer error = new Timer(1000,erase);
							error.start();
							error.setRepeats(false);
						}
						accountField.setText("");
						passwordField.setText("");
					}
				}
			}
		});
		accountField.setBounds(415, 85, 256, 61);
		contentPaneLogin.add(accountField);
		accountField.setHorizontalAlignment(SwingConstants.CENTER);
		accountField.setFont(new Font("Tahoma", Font.PLAIN, 30));
		accountField.setColumns(10);
		
		JLabel lblAccountNumber = new JLabel("Account Number:");
		lblAccountNumber.setBounds(10, 85, 385, 61);
		contentPaneLogin.add(lblAccountNumber);
		lblAccountNumber.setFont(new Font("Tahoma", Font.PLAIN, 50));
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setBounds(169, 157, 226, 61);
		contentPaneLogin.add(lblPassword);
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 50));
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(303, 297, 184, 81);
		contentPaneLogin.add(btnLogin);
		btnLogin.setForeground(Color.WHITE);
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 60));
		btnLogin.setBackground(new Color(51, 204, 51));
		
		passwordField = new JPasswordField();
		passwordField.setBounds(415, 165, 256, 61);
		contentPaneLogin.add(passwordField);
		passwordField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ENTER){
					if(accountInfo[4].equals("Active")){
						if (accountField.getText().equals(ATM.accountPW[0]) && Arrays.equals(passwordField.getPassword(), Password)){
							login.panel.remove(contentPaneLogin);
							login.panel.add(menu.contentPaneMenu);
							login.panel.revalidate();
							login.panel.repaint();
							attemptCount=0;
						}
						else{
							attemptCount++;
							if (attemptCount == 3){
								lblYourAccountIs.setVisible(true);
								ActionListener erase = new ActionListener() {
									public void actionPerformed(ActionEvent e){
										lblYourAccountIs.setVisible(false);
									}
								};
								Timer error = new Timer(10000,erase);
								error.start();
								error.setRepeats(false);
								
								String status = new String();
								status = "Inactive";
								accountInfo[4]=status;
								PrintWriter writer;
								try {
									writer = new PrintWriter(new FileOutputStream("AccountInformation.txt"));
									BufferedWriter bwriter = new BufferedWriter(writer);
									for(int i=0;i<5;i++){
										bwriter.write(accountInfo[i]);
										if(i!=4)
											bwriter.newLine();
									}
									bwriter.close();
								}
								catch (IOException e1) {
									// 	TODO Auto-generated catch block
									e1.printStackTrace();
								}
								ActionListener recovery = new ActionListener() {
									public void actionPerformed(ActionEvent e){
										String status = "Active";
										accountInfo[4]=status;
										PrintWriter writer;
										try{
											writer = new PrintWriter(new FileOutputStream("AccountInformation.txt"));
											BufferedWriter bwriter = new BufferedWriter(writer);
											for(int i=0;i<5;i++){
												bwriter.write(accountInfo[i]);
												if(i!=4)
													bwriter.newLine();
											}
											bwriter.close();
											attemptCount=0;
										}
										catch (IOException e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
									}
								};
								Timer changeStatus = new Timer(10000,recovery);
								changeStatus.start();
								changeStatus.setRepeats(false);
							}
							lblError.setVisible(true);
							ActionListener erase = new ActionListener() {
								public void actionPerformed(ActionEvent e){
									lblError.setVisible(false);
								}
							};
							Timer error = new Timer(1000,erase);
							error.start();
							error.setRepeats(false);
						}
						accountField.setText("");
						passwordField.setText("");
					}
				}
			}
		});
		passwordField.setHorizontalAlignment(SwingConstants.CENTER);
		passwordField.setFont(new Font("Tahoma", Font.PLAIN, 30));
		
		lblError = new JLabel("Invalid Credentials");
		lblError.setBounds(317, 237, 166, 25);
		contentPaneLogin.add(lblError);
		lblError.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblError.setForeground(new Color(255, 0, 51));
		lblError.setHorizontalAlignment(SwingConstants.CENTER);
		lblError.setVisible(false);
		
		lblYourAccountIs = new JLabel("Your account is disabled for 10 seconds.");
		lblYourAccountIs.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblYourAccountIs.setForeground(new Color(255, 0, 0));
		lblYourAccountIs.setHorizontalAlignment(SwingConstants.CENTER);
		lblYourAccountIs.setBounds(210, 271, 380, 25);
		contentPaneLogin.add(lblYourAccountIs);
		lblYourAccountIs.setVisible(false);
		
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(accountInfo[4].equals("Active")){
					if (accountField.getText().equals(ATM.accountPW[0]) && Arrays.equals(passwordField.getPassword(), Password)){
						login.panel.remove(contentPaneLogin);
						login.panel.add(menu.contentPaneMenu);
						login.panel.revalidate();
						login.panel.repaint();
						attemptCount=0;
					}
					else{
						attemptCount++;
						if (attemptCount == 3){
							lblYourAccountIs.setVisible(true);
							ActionListener erase = new ActionListener() {
								public void actionPerformed(ActionEvent e){
									lblYourAccountIs.setVisible(false);
								}
							};
							Timer error = new Timer(10000,erase);
							error.start();
							error.setRepeats(false);
							
							String status = new String();
							status = "Inactive";
							accountInfo[4]=status;
							PrintWriter writer;
							try {
								writer = new PrintWriter(new FileOutputStream("AccountInformation.txt"));
								BufferedWriter bwriter = new BufferedWriter(writer);
								for(int i=0;i<5;i++){
									bwriter.write(accountInfo[i]);
									if(i!=4)
										bwriter.newLine();
								}
								bwriter.close();
							}
							catch (IOException e1) {
								// 	TODO Auto-generated catch block
								e1.printStackTrace();
							}
							ActionListener recovery = new ActionListener() {
								public void actionPerformed(ActionEvent e){
									String status = "Active";
									accountInfo[4]=status;
									PrintWriter writer;
									try{
										writer = new PrintWriter(new FileOutputStream("AccountInformation.txt"));
										BufferedWriter bwriter = new BufferedWriter(writer);
										for(int i=0;i<5;i++){
											bwriter.write(accountInfo[i]);
											if(i!=4)
												bwriter.newLine();
										}
										bwriter.close();
										attemptCount=0;
									}
									catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
								}
							};
							Timer changeStatus = new Timer(10000,recovery);
							changeStatus.start();
							changeStatus.setRepeats(false);
						}
						lblError.setVisible(true);
						ActionListener erase = new ActionListener() {
							public void actionPerformed(ActionEvent e){
								lblError.setVisible(false);
							}
						};
						Timer error = new Timer(1000,erase);
						error.start();
						error.setRepeats(false);
					}
					accountField.setText("");
					passwordField.setText("");
				}
			}
		});
	}
}