import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Menu extends ATM{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JPanel contentPaneMenu;
	public Menu() {
		setTitle("Menu");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 800, 450);
		contentPaneMenu = new JPanel();
		contentPaneMenu.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPaneMenu);
		contentPaneMenu.setLayout(null);
		
		JLabel lblChoose = new JLabel("what would you like to do?");
		lblChoose.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblChoose.setHorizontalAlignment(SwingConstants.CENTER);
		lblChoose.setBounds(210, 78, 380, 37);
		contentPaneMenu.add(lblChoose);
		
		JButton btnBalance = new JButton("Balance");
		btnBalance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				login.panel.removeAll();
				login.panel.add(balance.contentPaneBalance);
				login.panel.revalidate();
				login.panel.repaint();
			}
		});
		btnBalance.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnBalance.setBounds(210, 126, 162, 82);
		contentPaneMenu.add(btnBalance);
		
		JButton btnTransfer = new JButton("Transfer");
		btnTransfer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login.panel.removeAll();
				login.panel.add(transfer.contentPaneTransfer);
				login.panel.revalidate();
				login.panel.repaint();
			}
		});
		btnTransfer.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnTransfer.setBounds(428, 126, 162, 82);
		contentPaneMenu.add(btnTransfer);
		
		JButton btnDeposit = new JButton("Deposit");
		btnDeposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login.panel.removeAll();
				login.panel.add(deposit.contentPaneDeposit);
				login.panel.revalidate();
				login.panel.repaint();
			}
		});
		btnDeposit.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnDeposit.setBounds(210, 240, 162, 82);
		contentPaneMenu.add(btnDeposit);
		
		JButton btnWithdraw = new JButton("Withdraw");
		btnWithdraw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login.panel.removeAll();
				login.panel.add(withdraw.contentPaneWithdraw);
				login.panel.revalidate();
				login.panel.repaint();
			}
		});
		btnWithdraw.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnWithdraw.setBounds(428, 240, 162, 82);
		contentPaneMenu.add(btnWithdraw);
		
		JButton btnChangePW = new JButton("Change Password");
		btnChangePW.setForeground(Color.WHITE);
		btnChangePW.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login.panel.removeAll();
				login.panel.add(changePW.contentPaneChangePW);
				login.panel.revalidate();
				login.panel.repaint();
			}
		});
		btnChangePW.setBackground(new Color(0, 51, 255));
		btnChangePW.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnChangePW.setBounds(10, 333, 287, 67);
		contentPaneMenu.add(btnChangePW);
		
		JButton btnLogout = new JButton("Logout");
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				login.panel.removeAll();
				login.panel.add(login.contentPaneLogin);
				login.panel.revalidate();
				login.panel.repaint();
			}
		});
		btnLogout.setBackground(new Color(255, 0, 51));
		btnLogout.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnLogout.setBounds(612, 333, 162, 67);
		contentPaneMenu.add(btnLogout);
		
		JLabel lblGreeting = new JLabel("Hello "+accountInfo[2]+" "+accountInfo[1]+",");
		lblGreeting.setHorizontalAlignment(SwingConstants.CENTER);
		lblGreeting.setFont(new Font("Tahoma", Font.PLAIN, 40));
		lblGreeting.setBounds(50, 11, 700, 56);
		contentPaneMenu.add(lblGreeting);
	}

}
